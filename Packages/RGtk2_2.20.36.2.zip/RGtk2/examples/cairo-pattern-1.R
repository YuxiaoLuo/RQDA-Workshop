cr$setSourceSurface(image, x, y)
cr$getSource()$setFilter(CairoFilter["nearest"])

