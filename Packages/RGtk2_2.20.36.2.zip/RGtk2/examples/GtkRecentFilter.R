filter <- gtkRecentFilter()
filter$addPattern("*")
