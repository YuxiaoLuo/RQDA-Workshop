# This function is not that useful in R.
# Instead, please use cairoVersionString() with compareVersion().
