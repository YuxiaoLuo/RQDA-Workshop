about$setTranslatorCredits(gettext("translator-credits"))
